# Default level is WARNING

import logging
# only warning message will print to console
logging.warning('oops, that may be a problem!')

# info is lower level than warning, will not print
logging.info('made it this far') 

