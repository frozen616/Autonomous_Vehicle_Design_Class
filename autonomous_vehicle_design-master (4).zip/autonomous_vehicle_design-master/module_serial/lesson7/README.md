# Arduino Serial.readByteUntil

Purpose: experiment with Serial.readBytesUntil

Use the Serial monitor program to send different messages.

Wait more than 1 second to send a message to see that the function times out.

Send a message that is only 2 characters long, terminated by the newline character to see that only 2 characters are read.

Send a meassage that is more than 4 characters long to see 4 characters are read and then the remaining characters are read as the program loops.

Send a message that is 4 characters long.

Send a message that is not terminated by the newline character.

What have you learned from these experiments? It's the best way to understand how these functions work and make them work for your purposes.