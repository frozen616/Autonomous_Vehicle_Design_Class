# Traveling, Self-Balancing Robot

The mobility goal for our two wheeled robot is
- balances itself
- balances itself and maintains position
- controlled directional travel: forward, backward, left turn, right turn

The robot needs multiple forms of control to achieve these behaviors. A diagram of the proposed control system is shown below. These systems control the rotation speed of the left and  right motors, the robot's angular position, and the robot's velocity.


![Multiple PID Control System](./images/pid_control.png "Multiple PID Control System")

[1] https://miro.medium.com/max/1400/0*HauxApy0BUFRi93d


## Motor Rotational Speed Control

The innermost level of PID control regulates the power applied to each motor to control each motor's rotational velocity. The turn speed is the set point. The encoder count and known control loop frequency provide the measured speed. The speed error is the difference between the turn speed and measured speed. This system should be tuned with its own set of control parameters: Kp, Ki, Kd.

This controller is essential for following a straight line while driving and providing stability when turning. Each motor needs its own regulator due to different electrical characteristics of forward/backward rotation.


## Robot Angle Control

This system helps the robot maintain an upright position by keeping the desired angle between the robot chassis and ground.

The balancing PID control system was implemented in a previous lesson. The two-wheeled robot is kept balanced by continually moving the wheels under the vehicle as it falls. The robot's wheels are driven in the direction of its fall to counteract the fall and keep the robot's center of gravity above its pivot point. Balancing the robot requires a low-latency control system to instantly correct any errors in tilt.

The control system diagram, above, shows angle 0 as the desired set point angle. The angle error is the difference between the robot's measured angle and desired angle. The PID angle controller output is the motors target speed. This system should be tuned with its own set of control parameters: Kp, Ki, Kd.


### Balancing Algorithm

The algorithm for balancing the robot is very simple.
- Get the robot tilt angle from the inertial measurement unit
- Calculate the error between the measured angle and the desired setpoint angle
- PID controller calculates the needed speed and direction for the motors to move the pivot point of the robot.



## Robot Speed Control

This controls the speed of the entire robot. This control system determines the robot's angle to the ground to achieve a desired speed. If the robot tilt is positive, it has to accelerate in that direction to avoid falling down. 

This system should be tuned with its own set of control parameters: Kp, Ki, Kd. 



## Stabilization Control Algorithm

```
dt = current time - last time

// get current angle and robot speed measurements
currentAngle = imu.getAngle()
currentRobotSpeed = (get left wheel speed - get right wheel speed) / 2


// control robot speed
robotSpeedError = currentRobotSpeed - targetRobotSpeed
pidRobotSpeed_output = robotPID.update(robotSpeedError, dt )

// robot speed pid affects target angle
targetAngle = angle0 = pidRobotSpeed_output

// control robot angle
angleError = currentAngle - targetAngle;
imuPID_output = imuPID.update(angleError, dt)

/* Typically there is a practical angle limit at which the
   robot cannot recover. Over this limit, it is best to turn off
   the motors and reset the system.
*/


if  abs(currentAngle - angle0) > limit
        pidIMU.reset()
        pidIMU = 0.0

        pidRobot.reset()
        pidRobotSpeed_output = 0.0

        leftwheel.reset()
        rightwheel.reset()

leftWheel.setSpeed(pidIMU_output + turnAmount)
rightWheel.setSpeed(pidIMU_output - turnAmount)

leftWheel.pidUpdate(dt)
rightWheel.pidUpdate(dt)

```



target 



https://medium.com/husarion-blog/fresh-look-at-self-balancing-robot-algorithm-d50d41711d58


https://wiki.aalto.fi/display/MEX/Awesome+self-balancing+robot


https://robotics.stackexchange.com/questions/11298/self-balancing-robot-control-system-strategies/


Differential drive

http://planning.cs.uiuc.edu/node659.html

https://www.youtube.com/watch?v=aE7RQNhwnPQ